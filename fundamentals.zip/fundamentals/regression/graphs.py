
class Graphs:

    def __init__(self):
        """

        """
